<?php 
session_start();
include("Connection.php");

// check if form's credential are ok 
$mail = $_POST["mail"];
$password = $_POST["password"];

// query
$sql = "SELECT * from utenti where Email='". $mail ."'and Password='".$password."'";

$result = $conn->query($sql);
if($result->num_rows > 0){
    $row = $result->fetch_assoc(); 
    $_SESSION["id"]=$row["ID"];
    $_SESSION["nome"]=$row["Nome"];
    $_SESSION["cognome"]=$row["Cognome"];
    $_SESSION["indirizzo"]=$row["indirizzo"];
    $_SESSION["mail"]=$row["Email"];
    $_SESSION["password"]=$row["Password"];
    $_SESSION["admin"]=$row["Admin"];
    

    header('Location: index.php');

}else{
    header('Location: index.php?msg=errore');
}
?>


