<?php
if(isset( $_SESSION["id"])){

    $sql = 'SELECT * from utenti where id like "%' . $_SESSION["id"] . '%"';
        $result = $conn->query($sql);
        if($result->num_rows > 0){
            if ($_SESSION["id"] == $row["ID"]) {
                $_SESSION["id"]=$row["ID"];
                $_SESSION["nome"]=$row["Nome"];
                $_SESSION["cognome"]=$row["Cognome"];
                $_SESSION["indirizzo"]=$row["indirizzo"];
                $_SESSION["mail"]=$row["Email"];
                $_SESSION["password"]=$row["Password"];
                $_SESSION["admin"]=$row["Admin"];
                
    
            }
    
        }
    
    }
